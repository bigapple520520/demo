/* 
 * @(#)XmlUtil.java    Created on 2014-2-24
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter.util;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

/**
 * XML解析工具类
 * 
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-24 上午11:48:35 $
 */
public class XmlUtil {

    private static Log log = LogFactory.getLog(XmlUtil.class);

    /**
     * 读取xml文本获取根元素
     * 
     * @param requestXml
     * @return
     */
    public static Element readXmlByXmlStr(String requestXml) {
        if (requestXml == null || "".equals(requestXml.trim())) {
            return null;
        }
        InputStream in;
        try {
            in = new ByteArrayInputStream(requestXml.getBytes("UTF-8"));
            return readXmlByInputStream(in);
        }
        catch (Exception e) {
            log.error("读取xml文本获取根元素出错，原因：", e);
        }
        return null;

    }

    /**
     * 读取输入流获取根元素
     * 
     * @param in
     * @return
     */
    public static Element readXmlByInputStream(InputStream in) {
        SAXReader reader = new SAXReader(false);
        Document doc = null;
        Element root = null;
        try {
            doc = reader.read(in);
            root = doc.getRootElement();
        }
        catch (DocumentException e) {
            log.error("读取输入流获取根元素出错，原因：", e);
        }
        return root;
    }
}
