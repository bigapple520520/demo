package com.winupon.paycenter.alipay;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Element;

import com.winupon.paycenter.PayConfig;
import com.winupon.paycenter.util.XmlUtil;

/**
 * 支付宝工具类
 * 
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-19 下午02:56:44 $
 */
public class AlipayUtil {

    private static Log log = LogFactory.getLog(AlipayUtil.class);

    /**
     * 获取支付宝订单签名信息
     * 
     * @param outTradeNo
     *            商户交易号(订单号)
     * @param subject
     *            商品名称
     * @param description
     *            商品描述
     * @param total
     *            商品总价
     * @param config
     *            支付参数配置
     * @return XML格式数据
     */
    public static String getSignInfo(String outTradeNo, String subject, String description, double total,
            PayConfig config) {
        // 组装订单参数
        String orderInfo = AlipayUtil.getSignData(outTradeNo, subject, description, total, config);
        try {
            // 对参数进行签名
            String signInfo = RSASignature.sign(orderInfo, config.getAlipayRSAPrivite());
            signInfo = URLEncoder.encode(signInfo, "utf-8");
            return AlipayUtil.getResultXml(100, "", orderInfo, signInfo);
        }
        catch (Exception e) {
            log.error("对订单信息签名出错，原因：", e);
            return AlipayUtil.getResultXml(101, "对订单信息签名出错，原因：" + e.getMessage(), "", "");
        }
    }

    /**
     * 返回支付宝签名XML信息
     * 
     * @param code
     * @param message
     * @param orderInfo
     * @param signInfo
     * @return
     */
    private static String getResultXml(int errcode, String message, String orderInfo, String signInfo) {
        StringBuffer xml = new StringBuffer();
        xml.append("<?xml version='1.0' encoding='GBK'?>");
        xml.append("<result>");
        xml.append("<errcode>%s</errcode>");
        xml.append("<message>%s</message>");
        xml.append("<orderinfo><![CDATA[%s]]></orderinfo>");
        xml.append("<signinfo>%s</signinfo>");
        xml.append("<signtype>RSA</signtype>");
        xml.append("</result>");
        return String.format(xml.toString(), errcode, message, orderInfo, signInfo);
    }

    /**
     * 准备支付宝待签名的数据
     * 
     * @param outTradeNo
     *            商户交易号(订单号)
     * @param subject
     *            商品名称
     * @param body
     *            商品描述
     * @param total
     *            商品总价
     * @param config
     *            支付参数配置
     * @return
     */
    private static String getSignData(String outTradeNo, String subject, String body, double total, PayConfig config) {
        String partner = config.getAlipayPartner();
        // 组装待签名数据
        String signData = "partner=" + "\"" + partner + "\"";
        signData += "&";
        signData += "seller=" + "\"" + partner + "\"";
        signData += "&";
        signData += "out_trade_no=" + "\"" + outTradeNo + "\"";
        signData += "&";
        signData += "subject=" + "\"" + subject + "\"";
        signData += "&";
        signData += "body=" + "\"" + body + "\"";
        signData += "&";
        signData += "total_fee=" + "\"" + total + "\"";
        signData += "&";
        signData += "notify_url=" + "\"" + config.getAlipayNotifyUrl() + "\"";
        return signData;
    }

    /**
     * 验证支付宝签名
     * 
     * @param request
     * @param config
     * @return
     */
    public static boolean checkSign(HttpServletRequest request, PayConfig config) {
        boolean retVal = false;
        try {
            // 获得待签名数据和签名值
            String sign = URLDecoder.decode(request.getParameter("sign"), "utf-8");
            String content = URLDecoder.decode(request.getParameter("content"), "utf-8");
            // 使用支付宝公钥验签名
            if (RSASignature.doCheck(content, sign, config.getAlipayRSAPublic())) {
                retVal = true;
            }
        }
        catch (Exception e) {
            log.error("验证支付宝签名出错，原因：", e);
        }
        return retVal;
    }

    /**
     * 获取支付结果
     * 
     * @param params
     * @param config
     * @return
     * @throws UnsupportedEncodingException
     */
    public static AlipayResult getPayResult(HttpServletRequest request, PayConfig config)
            throws UnsupportedEncodingException {
        request.setCharacterEncoding("utf-8");
        // 获得通知签名
        String sign = request.getParameter("sign");
        String notifyData = request.getParameter("notify_data");
        // 解析XML数据
        Element element = XmlUtil.readXmlByXmlStr(notifyData);
        AlipayResult result = new AlipayResult();
        result.setOutTradeNo(element.elementTextTrim("out_trade_no"));
        result.setSubject(element.elementTextTrim("subject"));
        result.setTotalFee(Double.valueOf(element.elementTextTrim("total_fee")));
        result.setTradeNo(element.elementTextTrim("trade_no"));
        result.setTradeStatus(element.elementTextTrim("trade_status"));
        // 获得待验签名的数据
        String verifyData = "notify_data=" + notifyData;
        // 使用支付宝公钥验签名
        result.setValid(RSASignature.doCheck(verifyData, sign, config.getAlipayRSAPublic()));
        return result;
    }
}
