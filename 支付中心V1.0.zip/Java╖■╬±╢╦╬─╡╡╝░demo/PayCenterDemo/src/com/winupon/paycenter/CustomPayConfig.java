/* 
 * @(#)CustomPayConfig.java    Created on 2014-2-24
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter;

public class CustomPayConfig extends PayConfig {

    @Override
    public String getAlipayNotifyUrl() {
        return "http://192.168.60.122/alipay/notifyReceiver";
    }

    @Override
    public String getAlipayPartner() {
        // 支付宝合作商户ID
        return null;
    }

    @Override
    public String getAlipayRSAPrivite() {
        // 支付宝商户（RSA）私钥
        return null;
    }

    @Override
    public String getAlipayRSAPublic() {
        // 支付宝（RSA）公钥
        return null;
    }

}
