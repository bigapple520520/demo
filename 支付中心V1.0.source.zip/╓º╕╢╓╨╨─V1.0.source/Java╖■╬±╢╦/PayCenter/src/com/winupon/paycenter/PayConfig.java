/* 
 * @(#)PayConfig.java    Created on 2014-2-19
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter;

/**
 * 服务端支付相关配置
 * 
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-19 下午02:25:47 $
 */
public abstract class PayConfig {

    /**
     * 支付宝合作商户ID
     * 
     * @return
     */
    public abstract String getAlipayPartner();

    /**
     * 支付宝商户（RSA）私钥
     * 
     * @return
     */
    public abstract String getAlipayRSAPrivite();

    /**
     * 支付宝（RSA）公钥
     * 
     * @return
     */
    public abstract String getAlipayRSAPublic();

    /**
     * 支付宝异步通知地址
     * 
     * @return
     */
    public abstract String getAlipayNotifyUrl();
}
