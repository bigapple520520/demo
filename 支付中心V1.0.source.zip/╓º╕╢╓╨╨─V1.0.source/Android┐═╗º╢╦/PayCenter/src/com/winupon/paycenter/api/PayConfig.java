/* 
 * @(#)PayConfig.java    Created on 2014-2-18
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter.api;


/**
 * 支付参数配置
 * 
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-18 下午3:43:34 $
 */
public abstract class PayConfig {

    public static final String ALIPAY_SERVER_URL = "https://msp.alipay.com/x.htm";

    private PayCallBack payCallBack;

    public final PayCallBack getPayCallBack() {
        return payCallBack;
    }

    public final void setPayCallBack(PayCallBack payCallBack) {
        this.payCallBack = payCallBack;
    }

    /**
     * 支付宝安全支付服务apk的名称，必须与assets目录下的apk名称一致
     * 
     * @return
     */
    public String getAlipayPluginName() {
        return "Alipay_msp_online.apk";
    }

    /**
     * 是否使用默认提示
     * 
     * @return
     */
    public boolean useDefaultTips() {
        return true;
    }

    /**
     * 支付宝生成订单服务地址
     * 
     * @return
     */
    public abstract String getAlipayOrderUrl();

    /**
     * 支付宝验签服务地址
     * 
     * @return
     */
    public abstract String getAlipayCheckSignUrl();

}
