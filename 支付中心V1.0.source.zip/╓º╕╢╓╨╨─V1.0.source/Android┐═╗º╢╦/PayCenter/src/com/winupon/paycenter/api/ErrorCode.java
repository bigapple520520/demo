/* 
 * @(#)ResultCode.java    Created on 2014-2-20
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter.api;

/**
 * 错误代码常量
 * 
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-20 上午10:35:04 $
 */
public class ErrorCode {

    /**
     * 网络不可用
     */
    public static final short NETWORK_NOT_CONNECTED = 1001;
    /**
     * 请求连接异常
     */
    public static final short REQUEST_CONNECT_ERROR = 1002;
    /**
     * 请求超时异常
     */
    public static final short REQUEST_TIMEOUT_ERROR = 1003;
    /**
     * 请求参数异常
     */
    public static final short REQUEST_PARAMS_ERROR = 1004;
    /**
     * 创建订单异常
     */
    public static final short CREATE_ORDER_ERROR = 1005;
    /**
     * 数据解析异常
     */
    public static final short DATA_PARSE_ERROR = 1006;
    /**
     * 验证签名异常
     */
    public static final short CHECK_SIGN_ERROR = 1007;
    /**
     * 支付失败
     */
    public static final short PAY_FAILURE_ERROR = 1008;

}
