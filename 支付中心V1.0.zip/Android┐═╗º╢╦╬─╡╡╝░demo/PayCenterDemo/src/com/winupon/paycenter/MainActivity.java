package com.winupon.paycenter;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

import com.winupon.paycenter.api.AlipayClient;
import com.winupon.paycenter.api.PayCallBack;
import com.winupon.paycenter.api.PayResult;
import com.winupon.paycenter.util.http.RequestParams;

public class MainActivity extends Activity {

    private final static String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnPay = (Button) findViewById(R.id.btnPay);
        btnPay.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                CustomPayConfig config = new CustomPayConfig();
                config.setPayCallBack(new PayCallBack() {

                    @Override
                    public void onSuccess(Activity activity, PayResult result) {
                        Log.v(TAG, "result:" + result);
                    }

                    @Override
                    public void onFailure(Activity activity, short errcode) {
                        Log.e(TAG, "errcode:" + errcode);
                    }
                });
                AlipayClient client = new AlipayClient(config, MainActivity.this);
                RequestParams params = new RequestParams();
                params.put("userId", "10000");
                params.put("title", "文具盒");
                client.pay(params);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

}
