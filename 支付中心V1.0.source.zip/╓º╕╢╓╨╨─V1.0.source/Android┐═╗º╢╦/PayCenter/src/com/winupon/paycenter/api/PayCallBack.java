/* 
 * @(#)PayCallBack.java    Created on 2014-2-19
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter.api;

import android.app.Activity;

/**
 * 支付回调接口
 * 
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-19 上午11:46:41 $
 */
public interface PayCallBack {

    /**
     * 支付成功
     * 
     * @param activity
     * @param result
     */
    public void onSuccess(Activity activity, PayResult result);

    /**
     * 支付失败
     * 
     * @param activity
     * @param errcode
     *            错误码，详细信息请参考ErrorCode.java
     */
    public void onFailure(Activity activity, short errcode);
}
