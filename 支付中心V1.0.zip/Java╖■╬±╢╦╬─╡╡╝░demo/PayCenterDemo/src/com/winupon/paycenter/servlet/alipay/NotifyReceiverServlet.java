/* 
 * @(#)NotifyReceiver.java    Created on 2014-2-24
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter.servlet.alipay;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.winupon.paycenter.CustomPayConfig;
import com.winupon.paycenter.alipay.AlipayResult;
import com.winupon.paycenter.alipay.AlipayUtil;
import com.winupon.paycenter.servlet.BaseServlet;

/**
 * 接收支付通知
 * 
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-24 上午11:42:58 $
 */
public class NotifyReceiverServlet extends BaseServlet {

    private static final long serialVersionUID = 3598872965539807579L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
            IOException {
        AlipayResult result = AlipayUtil.getPayResult(request, new CustomPayConfig());
        boolean success = false;
        // 验证签名成功
        if (result.isValid()) {
            if (result.isTradeFinished()) {
                // 交易成功继续判断订单是否有效、核对交易金额等
                success = true;
                System.out.println("Trade finished.");
            }
            else if (result.isWaitBuyerPay()) {
                // 等待付款，可不做处理
                System.out.println("Wait buyer pay.");
            }
            else {
                // 返回其他状态，可不处理
                System.out.println("Return other trade status:" + result.getTradeStatus());
            }
        }
        else {
            // 验证签名失败
            System.out.println("Check sign fail.");
        }
        // 若支付宝没有收到商户返回的“success”，将对同一笔订单的通知进行周期 性重发 (间隔时为： 2分钟 ,10分钟 ,1小时 ,2小时 ,6小时 ,15小时共 7次)。
        if (success) {
            System.out.println("success");
            print(response, AlipayResult.PAY_SUCCESS);
        }
        else {
            System.out.println("fail");
            print(response, AlipayResult.PAY_FAIL);
        }
    }
}
