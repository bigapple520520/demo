/* 
 * @(#)CustomPayConfig.java    Created on 2014-2-24
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter;

import com.winupon.paycenter.api.PayConfig;

/**
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-24 下午1:59:44 $
 */
public class CustomPayConfig extends PayConfig {

    @Override
    public String getAlipayCheckSignUrl() {
        return "http://192.168.60.122/alipay/checkSign";
    }

    @Override
    public String getAlipayOrderUrl() {
        return "http://192.168.60.122/alipay/createOrder";
    }

}
