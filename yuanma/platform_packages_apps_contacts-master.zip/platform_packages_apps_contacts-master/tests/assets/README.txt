File quick_test_recording.mp3 is copyright 2011 by
Hugo Hudson and is licensed under a
Creative Commons Attribution 3.0 Unported License:
  http://creativecommons.org/licenses/by/3.0/
