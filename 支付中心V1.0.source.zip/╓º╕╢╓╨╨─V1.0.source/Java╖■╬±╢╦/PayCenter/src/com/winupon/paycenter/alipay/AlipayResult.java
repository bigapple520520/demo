/* 
 * @(#)AlipayResult.java    Created on 2014-2-24
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter.alipay;

import java.io.Serializable;

/**
 * 支付宝支付结果
 * 
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-24 下午12:35:04 $
 */
public class AlipayResult implements Serializable {

    /**
     * 支付成功
     */
    public static final String PAY_SUCCESS = "success";
    /**
     * 支付失败
     */
    public static final String PAY_FAIL = "fail";

    private static final long serialVersionUID = -4386346923691602374L;

    private boolean isValid;// 验证签名是否有效
    private String subject;// 商品名称
    private String tradeNo; // 支付宝交易号
    private String outTradeNo; // 外部交易号（商户交易号）
    private double totalFee; // 交易金额
    private String tradeStatus; // 交易状态： TRADE_FINISHED 交易成功完成、 WAIT_BUYER_PAY 等待付款

    public boolean isValid() {
        return isValid;
    }

    public void setValid(boolean isValid) {
        this.isValid = isValid;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public double getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(double totalFee) {
        this.totalFee = totalFee;
    }

    public String getTradeStatus() {
        return tradeStatus;
    }

    public void setTradeStatus(String tradeStatus) {
        this.tradeStatus = tradeStatus;
    }

    /**
     * 是否交易完成
     * 
     * @return
     */
    public boolean isTradeFinished() {
        return "TRADE_FINISHED".equals(tradeStatus) || "TRADE_SUCCESS".equals(tradeStatus);
    }

    /**
     * 是否等待付款
     * 
     * @return
     */
    public boolean isWaitBuyerPay() {
        return "WAIT_BUYER_PAY".equals(tradeStatus);
    }

    @Override
    public String toString() {
        String format = "isValid: %s\nsubject: %s\ntradeNo: %s\noutTradeNo: %s\ntotalFee: %s\ntradeStatus: %s";
        return String.format(format, isValid, subject, tradeNo, outTradeNo, totalFee, tradeStatus);
    }

}
