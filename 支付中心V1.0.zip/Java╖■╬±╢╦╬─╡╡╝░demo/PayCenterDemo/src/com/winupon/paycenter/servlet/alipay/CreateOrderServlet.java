/* 
 * @(#)CreateOrderServlet.java    Created on 2014-2-24
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter.servlet.alipay;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.winupon.paycenter.CustomPayConfig;
import com.winupon.paycenter.alipay.AlipayUtil;
import com.winupon.paycenter.servlet.BaseServlet;

/**
 * 生成订单并返回支付宝签名结果
 * 
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-24 上午09:35:11 $
 */
public class CreateOrderServlet extends BaseServlet {

    private static final long serialVersionUID = -3697708741593987961L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
            IOException {
        request.setCharacterEncoding("utf-8");
        System.out.println(request.getParameter("userId"));
        System.out.println(request.getParameter("title"));
        String result = AlipayUtil.getSignInfo(getTradeNo(), "文具盒", "文具盒。。。", 0.01, new CustomPayConfig());
        print(response, result);
    }

    private String getTradeNo() {
        return new SimpleDateFormat("yyyyMMdd").format(new Date()) + System.currentTimeMillis();
    }
}
