/* 
 * @(#)CheckSignServlet.java    Created on 2014-2-24
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter.servlet.alipay;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.winupon.paycenter.CustomPayConfig;
import com.winupon.paycenter.alipay.AlipayUtil;
import com.winupon.paycenter.servlet.BaseServlet;

/**
 * 对支付宝返回订单信息验证签名
 * 
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-24 上午08:58:37 $
 */
public class CheckSignServlet extends BaseServlet {

    private static final long serialVersionUID = 6263793208109230531L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
            IOException {
        boolean result = AlipayUtil.checkSign(request, new CustomPayConfig());
        print(response, result);
    }
}
