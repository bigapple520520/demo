/* 
 * @(#)PayResult.java    Created on 2014-2-24
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter.api;

import java.io.Serializable;

/**
 * 支付结果
 * 
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-24 下午2:15:29 $
 */
public class PayResult implements Serializable {

    private static final long serialVersionUID = -5333644301901241609L;

    private String subject;// 商品名称
    private String outTradeNo; // 外部交易号（商户交易号）
    private double totalFee; // 交易金额

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public double getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(double totalFee) {
        this.totalFee = totalFee;
    }

    @Override
    public String toString() {
        String format = "subject: %s\noutTradeNo: %s\ntotalFee: %s";
        return String.format(format, subject, outTradeNo, totalFee);
    }
}
