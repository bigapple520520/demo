/* 
 * @(#)XmlUtil.java    Created on 2014-2-19
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import android.util.Xml;

/**
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-19 下午3:20:31 $
 */
public class XmlUtil {

    /**
     * 解析XML格式字符串(适用XML格式：<errcode>100</errcode> <message>message</message><data>data</data>)
     * 
     * @param xmlStr
     * @param nodes
     * @return
     * @throws XmlPullParserException
     * @throws IOException
     */
    public static Map<String, String> readXML(String xmlStr, String... nodes) throws Exception {
        if (StringUtil.isEmpty(xmlStr) || !xmlStr.startsWith("<?")) {
            return new HashMap<String, String>();
        }
        Map<String, String> data = new HashMap<String, String>();
        ByteArrayInputStream in = new ByteArrayInputStream(xmlStr.toString().getBytes());
        try {
            XmlPullParser parser = Xml.newPullParser();
            parser.setInput(in, "utf-8");
            List<String> values = XmlUtil.getNodes(nodes);
            int eventType = parser.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG) {
                    String name = parser.getName().toLowerCase(Locale.getDefault());
                    if (values.contains(name)) {
                        data.put(name, parser.nextText());
                    }
                }
                eventType = parser.next();
            }
        }
        finally {
            if (in != null) {
                in.close();
            }
        }
        return data;
    }

    private static List<String> getNodes(String... nodes) {
        List<String> values = new ArrayList<String>();
        for (String node : nodes) {
            values.add(node);
        }
        return values;
    }
}
