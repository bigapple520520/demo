/* 
 * @(#)AlipayClient.java    Created on 2014-2-18
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter.api;

import java.lang.ref.WeakReference;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.util.Map;

import org.apache.http.HttpException;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import com.winupon.paycenter.alipay.AlixId;
import com.winupon.paycenter.alipay.BaseHelper;
import com.winupon.paycenter.alipay.MobileSecurePayHelper;
import com.winupon.paycenter.alipay.MobileSecurePayer;
import com.winupon.paycenter.util.NetworkUtil;
import com.winupon.paycenter.util.StringUtil;
import com.winupon.paycenter.util.XmlUtil;
import com.winupon.paycenter.util.http.AsyncHttpClient;
import com.winupon.paycenter.util.http.AsyncHttpResponseHandler;
import com.winupon.paycenter.util.http.RequestParams;

/**
 * 支付宝支付客户端
 * 
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-18 下午3:53:15 $
 */
public class AlipayClient {

    private final PayConfig config;
    private PayHandler handler;
    private Activity activity;
    private static ProgressDialog progressDialog;
    private static String tag = "PayCenter";

    public AlipayClient(PayConfig config, Activity activity) {
        this.config = config;
        this.handler = new PayHandler(config, activity);
        this.activity = activity;
    }

    /**
     * 检查配置参数是否为空
     * 
     * @return
     */
    private boolean checkConfigs(PayCallBack callBack) {
        if (StringUtil.isEmpty(this.config.getAlipayPluginName())) {
            Log.v(tag, "支付宝安全插件名称为空");
            return false;
        }
        if (StringUtil.isEmpty(this.config.getAlipayOrderUrl())) {
            Log.v(tag, "支付宝生成订单服务地址为空");
            return false;
        }
        if (StringUtil.isEmpty(this.config.getAlipayCheckSignUrl())) {
            Log.v(tag, "支付宝验证签名服务地址为空");
            return false;
        }
        return true;
    }

    public void pay(RequestParams params) {
        final PayCallBack callBack = this.config.getPayCallBack();
        if (!NetworkUtil.isNetworkAvailable(activity)) {
            AlipayClient.showToast(config, activity, "没有可用的网络,请开启网络连接");
            callBack.onFailure(this.activity, ErrorCode.NETWORK_NOT_CONNECTED);
            return;
        }
        if (!checkConfigs(callBack)) {
            AlipayClient.showToast(config, activity, "请求参数错误");
            callBack.onFailure(this.activity, ErrorCode.REQUEST_PARAMS_ERROR);
            return;
        }
        MobileSecurePayHelper mspHelper = new MobileSecurePayHelper(this.activity);
        if (!mspHelper.detectMobile_sp(this.config)) {
            return;
        }
        progressDialog = BaseHelper.showProgress(this.activity, null, "正在提交数据，请稍后。。。", false, true);
        AsyncHttpClient client = AsyncHttpClient.getInstance();
        client.post(config.getAlipayOrderUrl(), params, new AsyncHttpResponseHandler() {

            @Override
            public void onSuccess(String content) {
                AlipayClient.closeProgress();
                try {
                    // 需要返回的节点名称
                    String[] nodes = { "errcode", "message", "orderinfo", "signinfo", "signtype" };
                    Map<String, String> result = XmlUtil.readXML(content, nodes);
                    if (!"100".equals(result.get("errcode"))) {
                        AlipayClient.showToast(config, activity, "获取订单信息失败，请稍后重试");
                        Log.e(tag, "获取订单信息出错，原因：" + result.get("message"));
                        callBack.onFailure(activity, ErrorCode.CREATE_ORDER_ERROR);
                        return;
                    }
                    String orderinfo = result.get("orderinfo");
                    String signinfo = result.get("signinfo");
                    String signtype = result.get("signtype");
                    // 组装好参数
                    String info = orderinfo + "&sign=" + "\"" + signinfo + "\"" + "&sign_type=" + "\"" + signtype
                            + "\"";
                    Log.v(tag, "OrderInfo:" + info);
                    // 调用pay方法进行支付
                    MobileSecurePayer msp = new MobileSecurePayer();
                    boolean bRet = msp.pay(info, handler, AlixId.RQF_PAY, activity);
                    if (bRet) {
                        // 显示“正在支付”进度条
                        progressDialog = BaseHelper.showProgress(activity, null, "正在支付，请稍后。。。", false, true);
                    }
                }
                catch (Exception e) {
                    AlipayClient.showToast(config, activity, "解析订单信息失败，请稍后重试");
                    e.printStackTrace();
                    Log.e(tag, "数据解析出错，原因：" + e);
                    callBack.onFailure(activity, ErrorCode.DATA_PARSE_ERROR);
                }
            }

            @Override
            protected void handleFailureMessage(Throwable e, String responseBody) {
                AlipayClient.closeProgress();
                if (!AlipayClient.hasRequestError(config, activity, e)) {
                    AlipayClient.showToast(config, activity, "创建订单失败，请稍后重试");
                    callBack.onFailure(activity, ErrorCode.CREATE_ORDER_ERROR);
                }
                Log.e(tag, "创建订单信息失败，原因：" + e);
            }

        });
    }

    private static boolean hasRequestError(PayConfig config, Activity activity, Throwable e) {
        if (e instanceof UnknownHostException || e instanceof ConnectException) {
            AlipayClient.showToast(config, activity, "请求失败，请稍后重试");
            config.getPayCallBack().onFailure(activity, ErrorCode.REQUEST_CONNECT_ERROR);
            return true;
        }
        if (e instanceof HttpException || e instanceof SocketTimeoutException) {
            AlipayClient.showToast(config, activity, "请求超时，请稍后重试");
            config.getPayCallBack().onFailure(activity, ErrorCode.REQUEST_TIMEOUT_ERROR);
            return true;
        }
        return false;
    }

    private static void closeProgress() {
        try {
            if (progressDialog != null) {
                progressDialog.dismiss();
                progressDialog = null;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static class PayHandler extends Handler {

        private final WeakReference<Activity> mActivity;
        private final PayConfig config;

        public PayHandler(PayConfig config, Activity activity) {
            this.config = config;
            this.mActivity = new WeakReference<Activity>(activity);
        }

        @Override
        public void handleMessage(final Message msg) {
            final PayHandler handler = this;
            final Activity activity = mActivity.get();
            final String data = (String) msg.obj;
            if (msg.what == AlixId.RQF_PAY) {
                closeProgress();
                Log.v(tag, "Trading results:" + data);
                checkSign(msg, handler, activity, config, data);
            }
        }
    }

    private static void checkSign(final Message msg, final Handler handler, final Activity activity,
            final PayConfig config, final String data) {
        final PayCallBack callBack = config.getPayCallBack();
        try {
            // 获取交易状态码
            final String status = getStatus(data);
            // 取消支付
            if ("6001".equals(status)) {
                AlipayClient.showToast(config, true, activity, "支付操作已取消");
                return;
            }
            // 当前订单交易已付款
            if ("4000".equals(status)) {
                return;
            }
            Log.v(tag, "Check sign...");
            JSONObject objContent = BaseHelper.string2JSON(data, ";");
            String result = objContent.getString("result");
            result = result.substring(1, result.length() - 1);
            // 获取待签名数据
            int iSignContentEnd = result.indexOf("&sign_type=");
            String signContent = result.substring(0, iSignContentEnd);
            // 获取签名
            JSONObject objResult = BaseHelper.string2JSON(result, "&");
            String signType = objResult.getString("sign_type").replace("\"", "");
            String sign = objResult.getString("sign").replace("\"", "");
            // 进行验签 返回验签结果
            if (signType.equalsIgnoreCase("RSA")) {
                // 服务端进行验签
                AsyncHttpClient client = AsyncHttpClient.getInstance();
                RequestParams params = new RequestParams();
                params.put("sign", URLEncoder.encode(sign, "utf-8"));
                params.put("content", URLEncoder.encode(signContent, "utf-8"));
                client.post(config.getAlipayCheckSignUrl(), params, new AsyncHttpResponseHandler() {

                    @Override
                    public void onSuccess(String content) {
                        if ("true".equals(content)) {
                            if ("9000".equals(status)) {
                                callBack.onSuccess(activity, AlipayClient.getPayResult(data));
                            }
                            else {
                                AlipayClient.showDialog(config, activity, "支付失败，请稍后重试");
                                Log.e(tag, "支付失败，支付响应信息：" + data);
                                callBack.onFailure(activity, ErrorCode.PAY_FAILURE_ERROR);
                            }
                        }
                        else {
                            AlipayClient.showDialog(config, activity, "您的订单信息已被非法篡改");
                        }
                        handler.handleMessage(msg);
                    }

                    @Override
                    protected void handleFailureMessage(Throwable e, String responseBody) {
                        if (!AlipayClient.hasRequestError(config, activity, e)) {
                            AlipayClient.showToast(config, activity, "请求验证签名数据失败");
                            Log.e(tag, "请求验证签名数据失败，原因：" + e);
                            config.getPayCallBack().onFailure(activity, ErrorCode.CHECK_SIGN_ERROR);
                        }
                    }
                });
            }
        }
        catch (JSONException e) {
            AlipayClient.showToast(config, activity, "支付结果解析失败");
            Log.e(tag, "json数据转换出错，原因：" + e);
            callBack.onFailure(activity, ErrorCode.DATA_PARSE_ERROR);
        }
        catch (Exception e) {
            AlipayClient.showDialog(config, activity, "支付失败，请稍后重试");
            Log.e(tag, "验证签名数据出错，原因：" + e);
            callBack.onFailure(activity, ErrorCode.CHECK_SIGN_ERROR);
        }
    }

    private static void showDialog(PayConfig config, Activity activity, String message) {
        if (config.useDefaultTips()) {
            BaseHelper.showDialog(activity, "提示", message, android.R.drawable.ic_dialog_info);
        }
    }

    private static void showToast(PayConfig config, Activity activity, String text) {
        AlipayClient.showToast(config, false, activity, text);
    }

    private static void showToast(PayConfig config, boolean ignoreConfig, Activity activity, String text) {
        if (ignoreConfig || (!ignoreConfig && config.useDefaultTips())) {
            Toast.makeText(activity, text, Toast.LENGTH_LONG).show();
        }
    }

    /**
     * 获取交易状态码
     * 
     * @param data
     * @return
     */
    private static String getStatus(String data) {
        // 获取交易状态码，具体状态代码请参看文档
        String tradeStatus = "resultStatus={";
        int imemoStart = data.indexOf("resultStatus=");
        imemoStart += tradeStatus.length();
        int imemoEnd = data.indexOf("};memo=");
        return data.substring(imemoStart, imemoEnd);
    }

    /**
     * 获取交易号和交易金额
     * 
     * @param data
     * @return
     */
    private static PayResult getPayResult(String data) {
        try {
            JSONObject objContent = BaseHelper.string2JSON(data, ";");
            String result = objContent.getString("result");
            result = result.substring(1, result.length() - 1);
            JSONObject json = BaseHelper.string2JSON(result, "&");
            PayResult payResult = new PayResult();
            payResult.setOutTradeNo(getJsonValue(json, "out_trade_no"));
            payResult.setSubject(getJsonValue(json, "subject"));
            payResult.setTotalFee(Double.valueOf(getJsonValue(json, "total_fee")));
            return payResult;
        }
        catch (JSONException e) {
            Log.e(tag, "解析支付结果失败，原因：" + e);
            return null;
        }
    }

    private static String getJsonValue(JSONObject data, String key) throws JSONException {
        String value = data.getString(key);
        if (value != null) {
            return value.replace("\"", "");
        }
        return "";
    }
}
