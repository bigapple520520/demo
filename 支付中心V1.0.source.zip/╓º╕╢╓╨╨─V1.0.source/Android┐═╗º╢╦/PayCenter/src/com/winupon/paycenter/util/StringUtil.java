/* 
 * @(#)StringUtil.java    Created on 2014-2-20
 * Copyright (c) 2014 ZDSoft Networks, Inc. All rights reserved.
 * $Id$
 */
package com.winupon.paycenter.util;

/**
 * 字符串工具类
 * 
 * @author leirz
 * @version $Revision: 1.0 $, $Date: 2014-2-20 上午10:54:55 $
 */
public class StringUtil {

    public static boolean isEmpty(String str) {
        if (str == null || str.trim().equals("")) {
            return true;
        }
        return false;
    }
}
